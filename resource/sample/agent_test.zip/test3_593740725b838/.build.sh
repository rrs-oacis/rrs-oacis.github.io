#!/bin/sh

java -jar ./library/rescue/adf/adf-core.jar -compile


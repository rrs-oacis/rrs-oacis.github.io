#!/bin/sh

rm -rf ./build
rm -rf ./precomp_data
rm -rf ./test-results
